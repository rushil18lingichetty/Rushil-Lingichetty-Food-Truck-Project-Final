import requests
import pandas as pd
import folium
import folium.plugins as plugins
from datetime import datetime, timedelta

# ==========================
# DATA COLLECTION
# ==========================

# Define the API key and endpoint for Google Places API.
API_KEY = 'AIzaSyA_EBVIlnB7DjmNeXVGbVcwNgjN1UgNG80'
URL = "https://maps.googleapis.com/maps/api/place/nearbysearch/json"

# Define the parameters for the Google Places API request.
params = {
    'key': API_KEY,
    'location': '39.7684,-86.1581',
    'radius': '5000',
    'type': 'restaurant',
    'keyword': 'food truck'
}

# Send the request and parse the JSON response.
response = requests.get(URL, params=params).json()
places = response.get('results', [])

# Extract relevant details for each food truck and append to a list.
data = []
for place in places:
    name = place.get('name')
    address = place.get('vicinity')
    rating = place.get('rating')
    website = place.get('website', 'N/A')
    lat = place['geometry']['location']['lat']
    lng = place['geometry']['location']['lng']
    data.append([name, address, rating, website, lat, lng])

# Convert the list into a pandas DataFrame for easy manipulation.
df = pd.DataFrame(data, columns=['Name', 'Address', 'Rating', 'Website', 'Latitude', 'Longitude'])

# ==========================
# FIND OPTIMAL ROUTE
# ==========================

# Define the endpoint for Google Directions API.
DIRECTIONS_API_URL = "https://maps.googleapis.com/maps/api/directions/json"

# Set up parameters for the Directions API request.
directions_params = {
    'origin': '39.7684,-86.1581',
    'destination': '39.7684,-86.1581',
    'waypoints': 'optimize:true|' + '|'.join([f"{lat},{lon}" for lat, lon in df[['Latitude', 'Longitude']].values]),
    'key': API_KEY
}

# Send the request and parse the JSON response.
directions_response = requests.get(DIRECTIONS_API_URL, params=directions_params).json()

# Get the optimal order of waypoints from the response.
ordered_waypoints = directions_response['routes'][0]['waypoint_order']

# Reorder the DataFrame based on the optimal route and reset index.
df = df.iloc[ordered_waypoints].reset_index(drop=True)

# Extract driving durations and distances from the response.
legs = directions_response['routes'][0]['legs']

cumulative_duration = 0
arrival_times = ['09:00:00']  # Start the journey at 9AM.
distances_miles = []

# Calculate cumulative driving durations and convert distances to miles.
for leg in legs[:len(df)-1]:
    cumulative_duration += leg['duration']['value']
    distance_km = float(leg['distance']['text'].split()[0])
    distance_miles = distance_km * 0.621371  # Conversion factor from km to miles.
    distances_miles.append(f"{distance_miles:.2f} miles")
    
    arrival_time = datetime.strptime('09:00:00', '%H:%M:%S') + timedelta(seconds=cumulative_duration)
    arrival_times.append(arrival_time.strftime('%H:%M:%S'))

# Add estimated arrival times and distances to the DataFrame.
df['ETA'] = arrival_times
df['Distance to Next Stop'] = distances_miles + ["0 miles"]  # Last stop's distance is 0 miles as it's the endpoint.

# Save the DataFrame to a CSV file.
df.to_csv("food_trucks_route.csv", index=False)

# ==========================
# DATA VISUALIZATION
# ==========================

# Initialize a folium map centered at the given coordinates.
m = folium.Map(location=[39.7684,-86.1581], zoom_start=13)

# Add markers for each food truck on the map with tooltips showing the name and rating.
for index, row in df.iterrows():
    location = (row['Latitude'], row['Longitude'])
    tooltip_content = f"{index+1}. {row['Name']} - Rating: {row['Rating']}"
    folium.Marker(
        location, 
        popup=f"{index+1}. {row['Name']} - Rating: {row['Rating']}", 
        icon=folium.Icon(icon=str(index+1)),
        tooltip=tooltip_content
    ).add_to(m)

# Get the coordinates for drawing the route on the map.
locations = df[["Latitude", "Longitude"]].values.tolist()

# Draw the optimal route on the map.
route_line = folium.PolyLine(locations, color="red", weight=2.5, opacity=1).add_to(m)

# Add arrows on the route to indicate the direction of travel.
plugins.PolyLineTextPath(
    route_line,
    "\u2192",
    repeat=True,
    offset=7,
    orientation='auto'
).add_to(m)

# Save the map visualization to an HTML file.
m.save('map.html')
